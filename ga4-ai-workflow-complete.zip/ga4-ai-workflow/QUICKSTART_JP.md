# クイックスタートガイド 🚀

このガイドでは、5分でGA4データ分析×AI活用ワークフローを始める方法を説明します。

---

## 📋 必要なもの

- ✅ Google Analytics 4 アカウント（またはデモアカウント）
- ✅ 生成AIサービス（ChatGPT / Claude / Gemini 等）
- ✅ 基本的なマーケティング知識

---

## 🎯 Step 1: GA4デモアカウントにアクセス（3分）

### 1-1. Googleアカウントでログイン

まだの場合は、[Googleアカウント](https://accounts.google.com/)を作成

### 1-2. GA4デモアカウントを追加

1. [GA4デモアカウント追加ページ](https://support.google.com/analytics/answer/6367342?hl=ja)にアクセス
2. 「デモアカウントにアクセス」をクリック
3. 「Google Merchandise Store」を選択
4. GA4管理画面が開いたら準備完了！

### 1-3. データを確認

- 左側メニュー > **レポート** > **ホーム**
- サンプルデータが表示されていればOK

---

## 🤖 Step 2: AIツールの準備（2分）

以下のいずれかを選択：

### オプションA: ChatGPT（推奨）

1. [ChatGPT](https://chat.openai.com/)にアクセス
2. アカウント作成（Googleアカウントで即登録可能）
3. 無料プラン（GPT-3.5）でも使えますが、**GPT-4推奨**

### オプションB: Claude

1. [Claude](https://claude.ai/)にアクセス
2. アカウント作成
3. **Claude 3.5 Sonnet推奨**

### オプションC: Gemini

1. [Gemini](https://gemini.google.com/)にアクセス
2. Googleアカウントでログイン
3. **Gemini Advanced推奨**（無料版でもOK）

---

## 📊 Step 3: 最初のワークフローを実践（10分）

### ワークフロー1を試す（最も簡単）

#### 3-1. GA4でランディングページを分析

```
GA4管理画面 > レポート > エンゲージメント > ランディングページ
```

以下を確認：
- セッション数が多いページTOP5
- 前期比成長率が高いページ

**例（Google Merchandise Store）:**
- Home: 14,000セッション
- New（新商品）: 4,348セッション（+25.7% 成長）← **注目！**
- Bags: 2,498セッション（+32.1% 成長）← **注目！**

#### 3-2. プロンプトをコピー

[`prompts/workflow1-content-planning.md`](./prompts/workflow1-content-planning.md)を開き、以下をコピー：

```markdown
# 役割
あなたは、BtoBリード獲得に強いコンテンツマーケターです。

# 状況（事実）
GA4のランディングページ分析によると、訪問者の多くが「新商品（New）」と「バッグ（Bags）」カテゴリのページから流入しています。
特に、Bagsカテゴリは前期比 +32.1%と急成長しています。

# 依頼
この「バッグ・ライフスタイル商品に関心がある層」からリード（メールアドレス）を獲得するための
お役立ち資料（ホワイトペーパー）のタイトル案を5つ、
最も効果的だと思うタイトルの目次案（3章立て）を1つ作成してください。
```

#### 3-3. AIに入力して結果を取得

ChatGPT / Claude に貼り付けて送信

**期待される回答例:**

```
【タイトル案】
1. 『なぜ今「バッグ」が売れるのか？｜データで読み解く2025年ライフスタイル商品トレンド』
2. 『月間売上+32%達成！Google Merch Shopに学ぶバッグ販売戦略』
...（計5つ）

【最推奨タイトルの目次】
第1章: バッグ市場の最新トレンド分析
第2章: 売れるバッグの3つの共通点
第3章: 今日から実践できる販売戦略
```

#### 3-4. 結果を活用

- 自社でホワイトペーパーを作成
- ブログ記事のネタとして活用
- 商品企画のヒントにする

---

## 🎓 次のステップ

### ワークフロー2に挑戦（中級）

**目的**: カート放棄率を改善するA/Bテスト案を立案

**手順**:
1. GA4で「探索 > ファネルデータ探索」を作成
2. [`prompts/workflow2-uiux-improvement.md`](./prompts/workflow2-uiux-improvement.md)のプロンプトを使用
3. AIから「原因仮説5つ」「A/Bテスト案3つ」を取得

**期待効果**: CVR 2-3倍改善

---

### ワークフロー3に挑戦（上級）

**目的**: Paid SearchとOrganic Searchの最適化戦略を立案

**手順**:
1. GA4で「集客 > トラフィック獲得」を確認
2. [`prompts/workflow3-traffic-strategy.md`](./prompts/workflow3-traffic-strategy.md)のプロンプトを使用
3. AIから各チャネルの改善施策を取得

**期待効果**: 総購入数 2倍達成

---

## 📚 学習リソース

### GA4を深く学ぶ

- [GA4公式ヘルプ](https://support.google.com/analytics/)
- [Google スキルショップ](https://skillshop.withgoogle.com/)
- [GA4ディメンションと指標](https://support.google.com/analytics/answer/9143382)

### AIプロンプトを極める

- [ChatGPT Prompt Engineering](https://platform.openai.com/docs/guides/prompt-engineering)
- [Claude Prompt Library](https://docs.anthropic.com/claude/prompt-library)
- [プロンプトエンジニアリング日本語ガイド](https://github.com/naohiro-nakazawa/prompt-engineering)

### マーケティング実践

- [Baymard Institute](https://baymard.com/)（EC UX研究）
- [CXL](https://cxl.com/)（コンバージョン最適化）
- [Moz](https://moz.com/beginners-guide-to-seo)（SEO）

---

## 🐛 トラブルシューティング

### Q: GA4デモアカウントのデータが表示されない

**A**: 以下を確認してください：
1. 正しいアカウント（Google Merchandise Store）を選択しているか
2. 日付範囲が適切か（デフォルトは「過去7日間」）
3. ブラウザのキャッシュをクリア

---

### Q: AIの回答が期待と違う

**A**: プロンプトを改善してください：
1. より具体的なデータ（数字）を含める
2. 「〇〇の形式で」と出力形式を指定
3. 「例を3つ挙げて」と数を指定
4. 何度か試して最良の回答を選ぶ

---

### Q: 自社データでどう活用すれば良い？

**A**: 段階的に進めてください：
1. **Week 1**: デモアカウントで練習
2. **Week 2**: 自社GA4でデータ確認
3. **Week 3**: プロンプトを自社データに合わせてカスタマイズ
4. **Week 4**: AIの回答を基に施策実行

---

## 📞 サポート

困ったときは：

1. **FAQ確認**: [`README_JP.md`](./README_JP.md)の「よくある質問」
2. **Issue作成**: [GitHub Issues](https://github.com/YOUR_USERNAME/ga4-ai-workflow/issues)
3. **コミュニティ**: [GitHub Discussions](https://github.com/YOUR_USERNAME/ga4-ai-workflow/discussions)

---

## ✅ 次回からのチェックリスト

毎週のルーティン：

```
□ GA4で週次データを確認（30分）
□ 異常値・トレンド変化をチェック
□ AIに改善施策を提案させる（15分）
□ 優先度の高い施策を1つ実行
□ 翌週の効果測定
```

---

**🎉 お疲れ様でした！**

これで最初のワークフローが完了しました。

次は [`roadmaps/3-month-implementation.md`](./roadmaps/3-month-implementation.md) で長期計画を確認しましょう。

---

最終更新: 2025年10月18日
